#! /usr/bin/env python3
"""Standalone desktop Library Management System.
Uses Tkinter for the interface and JSON for storage.
Run with: python3 library_desktop.py
"""

import csv
import json
import os
import tempfile
import tkinter as tk
from datetime import date, timedelta
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

BASE_DIR = Path(__file__).resolve().parent
DATA_FILE = BASE_DIR / "data" / "library.json"
LOAN_PERIOD_DAYS = 21
LATE_FEE_PENCE_PER_DAY = 100


def empty_data():
    return {"books": [], "loans": []}


def load_data():
    DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
    if not DATA_FILE.exists():
        save_data(empty_data())

    try:
        with DATA_FILE.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
        data.setdefault("books", [])
        data.setdefault("loans", [])
        return data
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Cannot read {DATA_FILE}: {exc}") from exc


def save_data(data):
    DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(
        prefix="library_", suffix=".json", dir=DATA_FILE.parent
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(data, handle, indent=4, ensure_ascii=False)
        os.replace(temp_name, DATA_FILE)
    finally:
        if os.path.exists(temp_name):
            os.remove(temp_name)


def find_book(data, isbn):
    return next(
        (book for book in data["books"] if book["isbn"] == isbn),
        None
    )


def active_loan(data, isbn):
    return next(
        (
            loan for loan in data["loans"]
            if loan["isbn"] == isbn and not loan.get("date_returned")
        ),
        None
    )


def fee_pence(due_date, on_date=None):
    on_date = on_date or date.today()
    days_late = max(
        0,
        (on_date - date.fromisoformat(due_date)).days
    )
    return days_late * LATE_FEE_PENCE_PER_DAY


def money(pence):
    return f"£{(pence or 0) / 100:.2f}"


def uk_date(value):
    if not value:
        return "—"
    return date.fromisoformat(value).strftime("%d/%m/%Y")


class LibraryDesktop(tk.Tk):

    def __init__(self):
        super().__init__()

        self.title("Library Management System")
        self.geometry("1180x720")
        self.minsize(900, 580)
        self.configure(bg="#f4f6f9")

        self._style()

        header = ttk.Frame(self, padding=(18, 14))
        header.pack(fill="x")

        ttk.Label(
            header,
            text="Library Management System",
            style="Title.TLabel"
        ).pack(side="left")

        ttk.Label(
            header,
            text=f"Today: {date.today().strftime('%d/%m/%Y')}",
            style="Muted.TLabel"
        ).pack(side="right")

        self.tabs = ttk.Notebook(self)
        self.tabs.pack(
            fill="both",
            expand=True,
            padx=16,
            pady=(0, 16)
        )

        self.catalogue_tab = ttk.Frame(self.tabs, padding=14)
        self.transactions_tab = ttk.Frame(self.tabs, padding=14)
        self.reports_tab = ttk.Frame(self.tabs, padding=14)

        self.tabs.add(self.catalogue_tab, text="  Catalogue  ")
        self.tabs.add(self.transactions_tab, text="  Transactions  ")
        self.tabs.add(self.reports_tab, text="  Reports  ")

        self._build_catalogue()
        self._build_transactions()
        self._build_reports()

        self.refresh_all()

    def _style(self):
        style = ttk.Style(self)

        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure(
            "TFrame",
            background="#f4f6f9"
        )

        style.configure(
            "TLabel",
            background="#f4f6f9",
            font=("Arial", 10)
        )

        style.configure(
            "Title.TLabel",
            font=("Arial", 19, "bold"),
            foreground="#17324d"
        )

        style.configure(
            "Muted.TLabel",
            foreground="#64748b"
        )

        style.configure(
            "Section.TLabel",
            font=("Arial", 13, "bold"),
            foreground="#17324d"
        )

        style.configure(
            "TButton",
            font=("Arial", 10),
            padding=(10, 7)
        )

        style.configure(
            "Accent.TButton",
            font=("Arial", 10, "bold"),
            padding=(12, 8)
        )

        style.configure(
            "Treeview",
            rowheight=29,
            font=("Arial", 10)
        )

        style.configure(
            "Treeview.Heading",
            font=("Arial", 10, "bold")
        )

        style.configure(
            "TNotebook.Tab",
            padding=(18, 9),
            font=("Arial", 10, "bold")
        )

    def _tree(self, parent, columns, headings, widths=None):

        frame = ttk.Frame(parent)
        frame.pack(fill="both", expand=True, pady=(10, 0))

        tree = ttk.Treeview(
            frame,
            columns=columns,
            show="headings"
        )

        for index, (column, heading) in enumerate(
            zip(columns, headings)
        ):
            tree.heading(column, text=heading)

            width = widths[index] if widths else 130

            tree.column(
                column,
                width=width,
                minwidth=70,
                anchor="w"
            )

        ybar = ttk.Scrollbar(
            frame,
            orient="vertical",
            command=tree.yview
        )

        xbar = ttk.Scrollbar(
            frame,
            orient="horizontal",
            command=tree.xview
        )

        tree.configure(
            yscrollcommand=ybar.set,
            xscrollcommand=xbar.set
        )

        tree.grid(row=0, column=0, sticky="nsew")
        ybar.grid(row=0, column=1, sticky="ns")
        xbar.grid(row=1, column=0, sticky="ew")

        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)

        tree.tag_configure("overdue", foreground="#b42318")
        tree.tag_configure("available", foreground="#137547")

        return tree

    # =========================================
    # CATALOGUE
    # =========================================

    def _build_catalogue(self):

        top = ttk.Frame(self.catalogue_tab)
        top.pack(fill="x")

        ttk.Label(
            top,
            text="Book catalogue",
            style="Section.TLabel"
        ).pack(side="left")

        ttk.Button(
            top,
            text="＋ Add new book",
            style="Accent.TButton",
            command=self.add_book_popup
        ).pack(side="right")

        stats = ttk.Frame(self.catalogue_tab)
        stats.pack(fill="x", pady=12)

        self.stat_labels = {}

        cards = [
            ("books", "Total books"),
            ("available", "Available"),
            ("loan", "On loan"),
            ("overdue", "Overdue")
        ]

        for key, caption in cards:

            card = ttk.LabelFrame(
                stats,
                text=caption,
                padding=(12, 8)
            )

            card.pack(
                side="left",
                fill="x",
                expand=True,
                padx=(0, 8)
            )

            value = ttk.Label(
                card,
                text="0",
                font=("Arial", 18, "bold"),
                foreground="#17324d"
            )

            value.pack(anchor="w")
            self.stat_labels[key] = value

        search = ttk.Frame(self.catalogue_tab)
        search.pack(fill="x", pady=(4, 0))

        ttk.Label(
            search,
            text="Search ISBN, title, author or category:"
        ).pack(side="left")

        self.book_search = tk.StringVar()

        entry = ttk.Entry(
            search,
            textvariable=self.book_search,
            width=38
        )

        entry.pack(side="left", padx=8)

        entry.bind(
            "<KeyRelease>",
            lambda _event: self.refresh_catalogue()
        )

        ttk.Button(
            search,
            text="Clear",
            command=lambda: self.book_search.set("")
        ).pack(side="left")

        self.books_tree = self._tree(
            self.catalogue_tab,
            ("isbn", "title", "author", "category", "status", "due"),
            ("ISBN", "Title", "Author", "Category", "Status", "Due date"),
            (145, 260, 180, 140, 110, 110)
        )

    # =========================================
    # TRANSACTIONS
    # =========================================

    def _build_transactions(self):

        ttk.Label(
            self.transactions_tab,
            text="Borrow and return books",
            style="Section.TLabel"
        ).pack(anchor="w")

        borrow = ttk.LabelFrame(
            self.transactions_tab,
            text="Borrow a book",
            padding=12
        )

        borrow.pack(fill="x", pady=(12, 10))

        ttk.Label(
            borrow,
            text="Available book:"
        ).pack(side="left")

        self.borrow_choice = tk.StringVar()

        self.borrow_combo = ttk.Combobox(
            borrow,
            textvariable=self.borrow_choice,
            state="readonly",
            width=65
        )

        self.borrow_combo.pack(side="left", padx=8)

        ttk.Button(
            borrow,
            text="Borrow selected book",
            style="Accent.TButton",
            command=self.borrow_selected
        ).pack(side="left")

        search = ttk.Frame(self.transactions_tab)
        search.pack(fill="x", pady=(4, 0))

        ttk.Label(
            search,
            text="Find transaction (ISBN, title or loan number):"
        ).pack(side="left")

        self.loan_search = tk.StringVar()

        loan_entry = ttk.Entry(
            search,
            textvariable=self.loan_search,
            width=35
        )

        loan_entry.pack(side="left", padx=8)

        loan_entry.bind(
            "<KeyRelease>",
            lambda _event: self.refresh_transactions()
        )

        ttk.Button(
            search,
            text="Return selected loan",
            command=self.return_selected
        ).pack(side="right")

        self.loans_tree = self._tree(
            self.transactions_tab,
            (
                "id", "isbn", "title", "out",
                "due", "returned", "status", "fee"
            ),
            (
                "Loan #", "ISBN", "Title", "Date out",
                "Due date", "Date returned", "Status", "Late fee"
            ),
            (70, 125, 210, 105, 105, 115, 100, 90)
        )

    # =========================================
    # REPORTS
    # =========================================

    def _build_reports(self):

        ttk.Label(
            self.reports_tab,
            text="Export reports",
            style="Section.TLabel"
        ).pack(anchor="w")

        ttk.Label(
            self.reports_tab,
            text="Choose a report. You will be asked where to save the CSV file.",
            style="Muted.TLabel"
        ).pack(anchor="w", pady=(5, 18))

        reports = [
            (
                "Catalogue report",
                "Export all books, ISBNs and availability.",
                "books",
                "library_catalogue.csv"
            ),
            (
                "Transactions report",
                "Export borrowing, return dates, statuses and late fees.",
                "transactions",
                "library_transactions.csv"
            ),
            (
                "Overdue books report",
                "Export current overdue loans and estimated fees.",
                "overdue",
                "overdue_books.csv"
            )
        ]

        for title, description, kind, filename in reports:

            card = ttk.LabelFrame(
                self.reports_tab,
                text=title,
                padding=14
            )

            card.pack(fill="x", pady=7)

            ttk.Label(
                card,
                text=description
            ).pack(side="left")

            ttk.Button(
                card,
                text="Save CSV",
                command=lambda k=kind, f=filename:
                    self.export_report(k, f)
            ).pack(side="right")

        ttk.Label(
            self.reports_tab,
            text=f"Data file: {DATA_FILE}",
            style="Muted.TLabel",
            wraplength=900
        ).pack(anchor="w", pady=(22, 0))

    # =========================================
    # REFRESH SCREENS
    # =========================================

    def refresh_all(self):

        try:
            self.refresh_catalogue()
            self.refresh_transactions()
            self.refresh_borrow_choices()

        except Exception as exc:
            messagebox.showerror("Library data error", str(exc))

    def refresh_catalogue(self):

        data = load_data()
        today = date.today().isoformat()

        available = sum(
            1 for book in data["books"]
            if not active_loan(data, book["isbn"])
        )

        active = [
            loan for loan in data["loans"]
            if not loan.get("date_returned")
        ]

        overdue = sum(
            1 for loan in active
            if loan["due_date"] < today
        )

        self.stat_labels["books"].configure(
            text=str(len(data["books"]))
        )

        self.stat_labels["available"].configure(
            text=str(available)
        )

        self.stat_labels["loan"].configure(
            text=str(len(active))
        )

        self.stat_labels["overdue"].configure(
            text=str(overdue)
        )

        query = self.book_search.get().strip().casefold()

        for item in self.books_tree.get_children():
            self.books_tree.delete(item)

        books = sorted(
            data["books"],
            key=lambda book: book["title"].casefold()
        )

        for book in books:

            searchable = (
                book.get("isbn", ""),
                book.get("title", ""),
                book.get("author", ""),
                book.get("category", "")
            )

            if query and not any(
                query in value.casefold()
                for value in searchable
            ):
                continue

            loan = active_loan(data, book["isbn"])

            status = "On loan" if loan else "Available"
            due = uk_date(loan["due_date"]) if loan else "—"

            self.books_tree.insert(
                "",
                "end",
                values=(
                    book["isbn"],
                    book["title"],
                    book["author"],
                    book["category"],
                    status,
                    due
                ),
                tags=("available" if not loan else "",)
            )

    def refresh_borrow_choices(self):

        data = load_data()

        choices = [
            f"{book['isbn']} | {book['title']}"
            for book in data["books"]
            if not active_loan(data, book["isbn"])
        ]

        self.borrow_combo["values"] = choices

        if self.borrow_choice.get() not in choices:
            self.borrow_choice.set(
                choices[0] if choices else ""
            )

    def refresh_transactions(self):

        data = load_data()
        query = self.loan_search.get().strip().casefold()

        for item in self.loans_tree.get_children():
            self.loans_tree.delete(item)

        for loan in reversed(data["loans"]):

            book = find_book(data, loan["isbn"]) or {}
            title = book.get("title", "Unknown book")

            searchable = (
                f"{loan['loan_id']} {loan['isbn']} {title}"
            ).casefold()

            if query and query not in searchable:
                continue

            returned = loan.get("date_returned")

            if returned:
                status = "Returned"
                fee = loan.get("late_fee_pence", 0)
            else:
                fee = fee_pence(loan["due_date"])

                status = (
                    "Overdue"
                    if loan["due_date"] < date.today().isoformat()
                    else "On loan"
                )

            self.loans_tree.insert(
                "",
                "end",
                iid=str(loan["loan_id"]),
                values=(
                    loan["loan_id"],
                    loan["isbn"],
                    title,
                    uk_date(loan["date_out"]),
                    uk_date(loan["due_date"]),
                    uk_date(returned),
                    status,
                    money(fee)
                ),
                tags=("overdue" if status == "Overdue" else "",)
            )

    # =========================================
    # ADD A BOOK
    # =========================================

    def add_book_popup(self):

        popup = tk.Toplevel(self)
        popup.title("Add a new book")
        popup.transient(self)
        popup.grab_set()
        popup.resizable(False, False)

        frame = ttk.Frame(popup, padding=20)
        frame.pack(fill="both", expand=True)

        ttk.Label(
            frame,
            text="Add a new book",
            style="Section.TLabel"
        ).grid(
            row=0,
            column=0,
            columnspan=2,
            sticky="w",
            pady=(0, 14)
        )

        fields = [
            ("ISBN", "isbn"),
            ("Title", "title"),
            ("Author", "author"),
            ("Category", "category")
        ]

        entries = {}

        for row, (label, key) in enumerate(fields, start=1):

            ttk.Label(
                frame,
                text=label + ":"
            ).grid(
                row=row,
                column=0,
                sticky="w",
                padx=(0, 12),
                pady=6
            )

            entry = ttk.Entry(frame, width=42)
            entry.grid(row=row, column=1, pady=6)
            entries[key] = entry

        entries["isbn"].focus_set()

        def save():

            values = {
                key: entry.get().strip()
                for key, entry in entries.items()
            }

            if not all(values.values()):
                messagebox.showwarning(
                    "Missing information",
                    "Please complete all four fields.",
                    parent=popup
                )
                return

            data = load_data()

            if find_book(data, values["isbn"]):
                messagebox.showerror(
                    "Duplicate ISBN",
                    "That ISBN is already in the catalogue.",
                    parent=popup
                )
                return

            data["books"].append(values)
            save_data(data)

            popup.destroy()
            self.refresh_all()

            messagebox.showinfo(
                "Book added",
                f"{values['title']} has been added to the catalogue.",
                parent=self
            )

        buttons = ttk.Frame(frame)

        buttons.grid(
            row=5,
            column=0,
            columnspan=2,
            sticky="e",
            pady=(14, 0)
        )

        ttk.Button(
            buttons,
            text="Cancel",
            command=popup.destroy
        ).pack(side="right", padx=(8, 0))

        ttk.Button(
            buttons,
            text="Save book",
            style="Accent.TButton",
            command=save
        ).pack(side="right")

        popup.bind("<Return>", lambda _event: save())

    # =========================================
    # BORROW A BOOK
    # =========================================

    def borrow_selected(self):

        choice = self.borrow_choice.get()

        if not choice:
            messagebox.showwarning(
                "No book selected",
                "There are no available books to borrow."
            )
            return

        isbn = choice.split(" | ", 1)[0]
        data = load_data()
        book = find_book(data, isbn)

        if not book or active_loan(data, isbn):
            messagebox.showerror(
                "Unavailable",
                "That book is no longer available. Refresh and try again."
            )
            self.refresh_all()
            return

        out = date.today()
        due = out + timedelta(days=LOAN_PERIOD_DAYS)

        next_id = max(
            (loan["loan_id"] for loan in data["loans"]),
            default=0
        ) + 1

        data["loans"].append({
            "loan_id": next_id,
            "isbn": isbn,
            "date_out": out.isoformat(),
            "due_date": due.isoformat(),
            "date_returned": None,
            "late_fee_pence": 0
        })

        save_data(data)
        self.refresh_all()

        messagebox.showinfo(
            "Book borrowed",
            f"{book['title']} borrowed successfully.\n"
            f"Due date: {uk_date(due.isoformat())}"
        )

    # =========================================
    # RETURN A BOOK
    # =========================================

    def return_selected(self):

        selected = self.loans_tree.selection()

        if not selected:
            messagebox.showwarning(
                "Select a transaction",
                "Select an active loan in the table first."
            )
            return

        loan_id = int(selected[0])
        data = load_data()

        loan = next(
            (
                item for item in data["loans"]
                if item["loan_id"] == loan_id
            ),
            None
        )

        if not loan or loan.get("date_returned"):
            messagebox.showerror(
                "Cannot return",
                "This loan has already been returned or cannot be found."
            )
            self.refresh_all()
            return

        returned = date.today()
        fee = fee_pence(loan["due_date"], returned)
        book = find_book(data, loan["isbn"]) or {}

        confirmed = messagebox.askyesno(
            "Confirm return",
            f"Record {book.get('title', 'this book')} as returned today?\n"
            f"Late fee: {money(fee)}"
        )

        if not confirmed:
            return

        loan["date_returned"] = returned.isoformat()
        loan["late_fee_pence"] = fee

        save_data(data)
        self.refresh_all()

        messagebox.showinfo(
            "Book returned",
            f"Return recorded.\nLate fee: {money(fee)}"
        )

    # =========================================
    # CSV REPORTS
    # =========================================

    def export_report(self, report_type, default_name):

        path = filedialog.asksaveasfilename(
            title="Save CSV report",
            defaultextension=".csv",
            initialfile=default_name,
            filetypes=[
                ("CSV files", "*.csv"),
                ("All files", "*.*")
            ]
        )

        if not path:
            return

        data = load_data()
        today = date.today()

        with open(
            path,
            "w",
            newline="",
            encoding="utf-8-sig"
        ) as handle:

            writer = csv.writer(handle)

            if report_type == "books":

                writer.writerow([
                    "ISBN", "Title", "Author",
                    "Category", "Status"
                ])

                for book in data["books"]:

                    status = (
                        "On loan"
                        if active_loan(data, book["isbn"])
                        else "Available"
                    )

                    writer.writerow([
                        book["isbn"],
                        book["title"],
                        book["author"],
                        book["category"],
                        status
                    ])

            elif report_type == "transactions":

                writer.writerow([
                    "Loan ID", "ISBN", "Title", "Author",
                    "Date Out", "Due Date", "Date Returned",
                    "Status", "Late Fee (£)"
                ])

                for loan in data["loans"]:

                    book = find_book(data, loan["isbn"]) or {}
                    returned = loan.get("date_returned")

                    if returned:
                        status = "Returned"
                        fee = loan.get("late_fee_pence", 0)
                    else:
                        status = (
                            "Overdue"
                            if date.fromisoformat(loan["due_date"]) < today
                            else "On loan"
                        )
                        fee = fee_pence(loan["due_date"], today)

                    writer.writerow([
                        loan["loan_id"],
                        loan["isbn"],
                        book.get("title", ""),
                        book.get("author", ""),
                        loan["date_out"],
                        loan["due_date"],
                        returned or "",
                        status,
                        f"{fee / 100:.2f}"
                    ])

            elif report_type == "overdue":

                writer.writerow([
                    "Loan ID", "ISBN", "Title", "Author",
                    "Date Out", "Due Date", "Days Overdue",
                    "Estimated Late Fee (£)"
                ])

                for loan in data["loans"]:

                    if (
                        not loan.get("date_returned")
                        and date.fromisoformat(loan["due_date"]) < today
                    ):

                        book = find_book(data, loan["isbn"]) or {}

                        days = (
                            today - date.fromisoformat(loan["due_date"])
                        ).days

                        fee = fee_pence(loan["due_date"], today)

                        writer.writerow([
                            loan["loan_id"],
                            loan["isbn"],
                            book.get("title", ""),
                            book.get("author", ""),
                            loan["date_out"],
                            loan["due_date"],
                            days,
                            f"{fee / 100:.2f}"
                        ])

        messagebox.showinfo(
            "Report saved",
            f"Your report has been saved to:\n{path}"
        )


if __name__ == "__main__":
    LibraryDesktop().mainloop()

