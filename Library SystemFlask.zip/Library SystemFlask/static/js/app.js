
const page = document.body.dataset.page;
const today = new Date();
const todayLabel = document.getElementById("todayLabel");

if (todayLabel) {
  todayLabel.textContent = today.toLocaleDateString("en-GB", {
    weekday: "short",
    day: "numeric",
    month: "long",
    year: "numeric"
  });
}

function money(pence) {
  return new Intl.NumberFormat("en-GB", {
    style: "currency",
    currency: "GBP"
  }).format((Number(pence) || 0) / 100);
}

function ukDate(value) {
  if (!value) return "—";
  const [year, month, day] = value.split("-");
  return `${day}/${month}/${year}`;
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  })[char]);
}

let toastTimer;

function showToast(message, isError = false) {
  const toast = document.getElementById("toast");
  if (!toast) return;

  toast.textContent = message;
  toast.classList.toggle("error", isError);
  toast.classList.add("show");

  clearTimeout(toastTimer);

  toastTimer = setTimeout(
    () => toast.classList.remove("show"),
    3200
  );
}

async function api(url, options = {}) {
  const response = await fetch(url, {
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {})
    },
    ...options
  });

  const result = await response.json();

  if (!response.ok) {
    throw new Error(result.error || "Something went wrong.");
  }

  return result;
}

async function getData() {
  return api("/api/data");
}

function statusPill(status) {
  const className = status.toLowerCase().replace(/\s+/g, "-");

  return `<span class="pill ${className}">${escapeHtml(status)}</span>`;
}

/* ==================================
   CATALOGUE PAGE
================================== */

if (page === "catalogue") {

  const modal = document.getElementById("bookModal");
  const form = document.getElementById("bookForm");

  const openModal = () => {
    modal.classList.add("visible");
    modal.setAttribute("aria-hidden", "false");
    form.querySelector("input").focus();
  };

  const closeModal = () => {
    modal.classList.remove("visible");
    modal.setAttribute("aria-hidden", "true");
    form.reset();
  };

  document.getElementById("openBookModal")
    .addEventListener("click", openModal);

  document.getElementById("closeBookModal")
    .addEventListener("click", closeModal);

  document.getElementById("cancelBook")
    .addEventListener("click", closeModal);

  modal.addEventListener("click", event => {
    if (event.target === modal) closeModal();
  });

  document.addEventListener("keydown", event => {
    if (event.key === "Escape") closeModal();
  });

  async function renderCatalogue() {

    try {

      const data = await getData();

      const todayISO = new Date().toISOString().slice(0, 10);

      const available = data.books.filter(
        book => book.status === "Available"
      ).length;

      const onLoan = data.books.length - available;

      const overdue = data.loans.filter(loan =>
        !loan.date_returned && loan.due_date < todayISO
      ).length;

      document.getElementById("totalBooks").textContent =
        data.books.length;

      document.getElementById("availableBooks").textContent =
        available;

      document.getElementById("onLoanBooks").textContent =
        onLoan;

      document.getElementById("overdueBooks").textContent =
        overdue;

      const query = document.getElementById("bookSearch")
        .value.trim().toLowerCase();

      const books = data.books.filter(book =>
        [book.isbn, book.title, book.author, book.category]
          .some(value => value.toLowerCase().includes(query))
      );

      document.getElementById("bookCount").textContent =
        `${books.length} ${books.length === 1 ? "book" : "books"}`;

      const tbody = document.getElementById("booksTable");

      tbody.innerHTML = books.length ? books.map(book => `
        <tr>
          <td class="isbn-cell">${escapeHtml(book.isbn)}</td>
          <td><strong>${escapeHtml(book.title)}</strong></td>
          <td>${escapeHtml(book.author)}</td>
          <td>${escapeHtml(book.category)}</td>
          <td>${statusPill(book.status)}</td>
          <td>${book.active_loan ? ukDate(book.active_loan.due_date) : "—"}</td>
        </tr>
      `).join("") :
      `<tr>
        <td colspan="6" class="empty-state">
          No books match your search.
        </td>
      </tr>`;

    } catch (error) {
      showToast(error.message, true);
    }
  }

  document.getElementById("bookSearch")
    .addEventListener("input", renderCatalogue);

  form.addEventListener("submit", async event => {

    event.preventDefault();

    const payload = Object.fromEntries(
      new FormData(form).entries()
    );

    try {

      const result = await api("/api/books", {
        method: "POST",
        body: JSON.stringify(payload)
      });

      closeModal();
      showToast(result.message);
      renderCatalogue();

    } catch (error) {
      showToast(error.message, true);
    }
  });

  renderCatalogue();
}


/* ==================================
   TRANSACTIONS PAGE
================================== */

if (page === "transactions") {

  let allLoans = [];

  async function renderTransactions() {

    try {

      const data = await getData();

      allLoans = data.loans;

      const active = allLoans.filter(
        loan => !loan.date_returned
      );

      const overdue = active.filter(
        loan => loan.status === "Overdue"
      );

      const returnedFees = allLoans
        .filter(loan => loan.date_returned)
        .reduce(
          (sum, loan) => sum + (loan.late_fee_pence || 0),
          0
        );

      document.getElementById("activeLoans").textContent =
        active.length;

      document.getElementById("overdueLoans").textContent =
        overdue.length;

      document.getElementById("recordedFees").textContent =
        money(returnedFees);

      const select = document.getElementById("borrowIsbn");

      const availableBooks = data.books.filter(
        book => book.status === "Available"
      );

      select.innerHTML =
        `<option value="">Select a book...</option>` +
        availableBooks.map(book =>
          `<option value="${escapeHtml(book.isbn)}">
            ${escapeHtml(book.title)} — ${escapeHtml(book.isbn)}
          </option>`
        ).join("");

      renderLoanRows();

    } catch (error) {
      showToast(error.message, true);
    }
  }


  function renderLoanRows() {

    const query = document.getElementById("transactionSearch")
      .value.toLowerCase().trim();

    const loans = allLoans.filter(loan =>
      [loan.title, loan.isbn, String(loan.loan_id)]
        .some(value => String(value).toLowerCase().includes(query))
    );

    document.getElementById("transactionCount").textContent =
      `${loans.length} ${loans.length === 1 ? "transaction" : "transactions"}`;

    document.getElementById("transactionsTable").innerHTML =
      loans.length ?

      loans.slice().reverse().map(loan => `
        <tr>
          <td>#${loan.loan_id}</td>

          <td>
            <strong>${escapeHtml(loan.title)}</strong>
            <small class="sub-cell">${escapeHtml(loan.isbn)}</small>
          </td>

          <td>${ukDate(loan.date_out)}</td>

          <td>${ukDate(loan.due_date)}</td>

          <td>${ukDate(loan.date_returned)}</td>

          <td>${statusPill(loan.status)}</td>

          <td>${money(loan.fee_pence)}</td>

          <td>
            ${!loan.date_returned ?
              `<button
                class="button button-small button-light return-button"
                data-loan="${loan.loan_id}">
                Return
              </button>` :
              `<span class="muted">Completed</span>`
            }
          </td>
        </tr>
      `).join("") :

      `<tr>
        <td colspan="8" class="empty-state">
          No transactions found.
        </td>
      </tr>`;
  }


  document.getElementById("transactionSearch")
    .addEventListener("input", renderLoanRows);


  document.getElementById("borrowForm")
    .addEventListener("submit", async event => {

      event.preventDefault();

      const isbn = document.getElementById("borrowIsbn").value;

      if (!isbn) return;

      try {

        const result = await api("/api/transactions/borrow", {
          method: "POST",
          body: JSON.stringify({ isbn })
        });

        showToast(
          `${result.title} borrowed. Due ${ukDate(result.loan.due_date)}.`
        );

        renderTransactions();

      } catch (error) {
        showToast(error.message, true);
      }
    });


  document.getElementById("transactionsTable")
    .addEventListener("click", async event => {

      const button = event.target.closest(".return-button");

      if (!button) return;

      if (!confirm("Confirm that this book is being returned today?")) {
        return;
      }

      try {

        const result = await api(
          `/api/transactions/${button.dataset.loan}/return`,
          {
            method: "POST",
            body: JSON.stringify({})
          }
        );

        showToast(
          `Book returned. Late fee: ${money(result.late_fee_pence)}.`
        );

        renderTransactions();

      } catch (error) {
        showToast(error.message, true);
      }
    });

  renderTransactions();
}


/* ==================================
   REPORTS PAGE
================================== */

if (page === "reports") {

  document.querySelectorAll("[data-report]").forEach(button => {

    button.addEventListener("click", () => {

      window.location.href =
        `/api/reports/${button.dataset.report}.csv`;

    });

  });

}

