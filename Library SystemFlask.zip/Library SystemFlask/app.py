from flask import Flask, render_template, request, jsonify, send_file
from datetime import date, timedelta
from pathlib import Path
from io import StringIO, BytesIO
import csv
import json
import os
import tempfile
import threading

app = Flask(__name__)

BASE_DIR = Path(__file__).resolve().parent
DATA_FILE = BASE_DIR / "data" / "library.json"
DATA_LOCK = threading.Lock()

LOAN_PERIOD_DAYS = 21
LATE_FEE_PENCE_PER_DAY = 100


def empty_data():
    return {"books": [], "loans": []}


def load_data():
    DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
    if not DATA_FILE.exists():
        save_data(empty_data())
    try:
        with DATA_FILE.open("r", encoding="utf-8") as file:
            data = json.load(file)
        data.setdefault("books", [])
        data.setdefault("loans", [])
        return data
    except (json.JSONDecodeError, OSError) as exc:
        raise RuntimeError(
            f"Could not read {DATA_FILE}. Check the JSON file before continuing."
        ) from exc


def save_data(data):
    """Write JSON atomically to reduce the risk of a damaged file."""
    DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary_name = tempfile.mkstemp(
        prefix="library_", suffix=".json", dir=DATA_FILE.parent
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as file:
            json.dump(data, file, indent=4, ensure_ascii=False)
        os.replace(temporary_name, DATA_FILE)
    finally:
        if os.path.exists(temporary_name):
            os.remove(temporary_name)


def find_book(data, isbn):
    return next((book for book in data["books"] if book["isbn"] == isbn), None)


def active_loan(data, isbn):
    return next(
        (
            loan for loan in data["loans"]
            if loan["isbn"] == isbn and loan.get("date_returned") is None
        ),
        None,
    )


def late_fee_pence(due_date, comparison_date):
    due = date.fromisoformat(due_date)
    compared = date.fromisoformat(comparison_date)
    days_late = max(0, (compared - due).days)
    return days_late * LATE_FEE_PENCE_PER_DAY


def next_loan_id(data):
    return max((loan["loan_id"] for loan in data["loans"]), default=0) + 1


@app.get("/")
def catalogue_page():
    return render_template("index.html")


@app.get("/transactions")
def transactions_page():
    return render_template("transactions.html")


@app.get("/reports")
def reports_page():
    return render_template("reports.html")


@app.get("/api/data")
def api_data():
    with DATA_LOCK:
        data = load_data()

    today = date.today().isoformat()
    books = []
    for book in data["books"]:
        loan = active_loan(data, book["isbn"])
        item = dict(book)
        item["status"] = "On loan" if loan else "Available"
        item["active_loan"] = loan
        books.append(item)

    loans = []
    for loan in data["loans"]:
        item = dict(loan)
        book = find_book(data, loan["isbn"])
        item["title"] = book["title"] if book else "Unknown book"
        item["author"] = book["author"] if book else ""
        if loan.get("date_returned"):
            item["status"] = "Returned"
            item["fee_pence"] = loan.get("late_fee_pence", 0)
        else:
            item["status"] = (
                "Overdue" if loan["due_date"] < today else "On loan"
            )
            item["fee_pence"] = late_fee_pence(loan["due_date"], today)
        loans.append(item)

    return jsonify({"books": books, "loans": loans})


@app.post("/api/books")
def add_book():
    payload = request.get_json(silent=True) or {}
    isbn = str(payload.get("isbn", "")).strip()
    title = str(payload.get("title", "")).strip()
    author = str(payload.get("author", "")).strip()
    category = str(payload.get("category", "")).strip()

    if not all([isbn, title, author, category]):
        return jsonify({"error": "Please complete all four fields."}), 400

    with DATA_LOCK:
        data = load_data()
        if find_book(data, isbn):
            return jsonify({"error": "That ISBN is already in the catalogue."}), 409

        data["books"].append({
            "isbn": isbn,
            "title": title,
            "author": author,
            "category": category,
        })
        save_data(data)

    return jsonify({"message": "Book added successfully."}), 201


@app.post("/api/transactions/borrow")
def borrow_book():
    payload = request.get_json(silent=True) or {}
    isbn = str(payload.get("isbn", "")).strip()

    if not isbn:
        return jsonify({"error": "Choose a book to borrow."}), 400

    with DATA_LOCK:
        data = load_data()
        book = find_book(data, isbn)
        if not book:
            return jsonify({"error": "Book not found in the catalogue."}), 404
        if active_loan(data, isbn):
            return jsonify({"error": "This book is already on loan."}), 409

        date_out = date.today()
        due_date = date_out + timedelta(days=LOAN_PERIOD_DAYS)
        loan = {
            "loan_id": next_loan_id(data),
            "isbn": isbn,
            "date_out": date_out.isoformat(),
            "due_date": due_date.isoformat(),
            "date_returned": None,
            "late_fee_pence": 0,
        }
        data["loans"].append(loan)
        save_data(data)

    return jsonify({
        "message": "Book borrowed successfully.",
        "loan": loan,
        "title": book["title"],
    }), 201


@app.post("/api/transactions/<int:loan_id>/return")
def return_book(loan_id):
    with DATA_LOCK:
        data = load_data()
        loan = next(
            (item for item in data["loans"] if item["loan_id"] == loan_id),
            None,
        )
        if not loan:
            return jsonify({"error": "Loan record not found."}), 404
        if loan.get("date_returned"):
            return jsonify({"error": "This book has already been returned."}), 409

        returned = date.today().isoformat()
        fee = late_fee_pence(loan["due_date"], returned)
        loan["date_returned"] = returned
        loan["late_fee_pence"] = fee
        save_data(data)

    return jsonify({
        "message": "Book returned successfully.",
        "date_returned": returned,
        "late_fee_pence": fee,
    })


@app.get("/api/reports/<report_type>.csv")
def download_report(report_type):
    with DATA_LOCK:
        data = load_data()

    output = StringIO()
    writer = csv.writer(output)
    today = date.today().isoformat()

    if report_type == "books":
        writer.writerow(["ISBN", "Title", "Author", "Category", "Status"])
        for book in data["books"]:
            status = "On loan" if active_loan(data, book["isbn"]) else "Available"
            writer.writerow([
                book["isbn"], book["title"], book["author"],
                book["category"], status
            ])
        filename = "library_catalogue.csv"

    elif report_type == "transactions":
        writer.writerow([
            "Loan ID", "ISBN", "Title", "Author", "Date Out",
            "Due Date", "Date Returned", "Status", "Late Fee (£)"
        ])
        for loan in data["loans"]:
            book = find_book(data, loan["isbn"]) or {}
            returned = loan.get("date_returned")
            if returned:
                status = "Returned"
                fee = loan.get("late_fee_pence", 0)
            else:
                status = "Overdue" if loan["due_date"] < today else "On loan"
                fee = late_fee_pence(loan["due_date"], today)
            writer.writerow([
                loan["loan_id"], loan["isbn"], book.get("title", ""),
                book.get("author", ""), loan["date_out"], loan["due_date"],
                returned or "", status, f"{fee / 100:.2f}"
            ])
        filename = "library_transactions.csv"

    elif report_type == "overdue":
        writer.writerow([
            "Loan ID", "ISBN", "Title", "Author", "Date Out",
            "Due Date", "Days Overdue", "Estimated Late Fee (£)"
        ])
        for loan in data["loans"]:
            if loan.get("date_returned") is None and loan["due_date"] < today:
                book = find_book(data, loan["isbn"]) or {}
                days = (date.fromisoformat(today) -
                        date.fromisoformat(loan["due_date"])).days
                fee = late_fee_pence(loan["due_date"], today)
                writer.writerow([
                    loan["loan_id"], loan["isbn"], book.get("title", ""),
                    book.get("author", ""), loan["date_out"], loan["due_date"],
                    days, f"{fee / 100:.2f}"
                ])
        filename = "overdue_books.csv"

    else:
        return jsonify({"error": "Unknown report type."}), 404

    content = output.getvalue()
    # Excel on UK Windows systems generally opens UTF-8 CSV more reliably with a BOM.
    csv_bytes = BytesIO(("\ufeff" + content).encode("utf-8"))
    csv_bytes.seek(0)
    return send_file(
        csv_bytes,
        mimetype="text/csv",
        as_attachment=True,
        download_name=filename,
    )


if __name__ == "__main__":
    with DATA_LOCK:
        if not DATA_FILE.exists():
            save_data(empty_data())
    app.run(debug=True, host="127.0.0.1", port=5000)
